﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BudgetApp
{
    public partial class ResetPassword : Form
    {
        public ResetPassword()
        {
            InitializeComponent();
        }

        private void btnLoginOnResetPwdPg_Click(object sender, EventArgs e)
        {
            Home resetPasswordToHome = new Home();
            resetPasswordToHome.ShowDialog();
        }

        private void ResetPassword_Load(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}
