﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coupons.Models
{
    public static class APIKey
    {
        public static string CouponsAPIKey { get; } = "rNjLdMIk";
    }
}
