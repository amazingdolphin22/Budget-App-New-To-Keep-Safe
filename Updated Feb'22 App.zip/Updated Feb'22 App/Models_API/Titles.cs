﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Coupons.Models
{
    public static class Titles
    {
        public static string MessageBoxTitle = "Coupon Discount App";
    }
}
