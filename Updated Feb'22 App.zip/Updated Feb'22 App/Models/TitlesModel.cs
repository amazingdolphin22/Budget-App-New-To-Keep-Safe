﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BudgetApp.Models
{
    public static class TitlesModel
    {
        public static string MessageBoxTitle { get; } = "Budget App";
    }
}
