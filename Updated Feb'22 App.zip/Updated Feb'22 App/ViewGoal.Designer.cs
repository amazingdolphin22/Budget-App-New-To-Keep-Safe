﻿namespace BudgetApp
{
    partial class ViewGoal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblViewGoal = new System.Windows.Forms.Label();
            this.txtSetGoal = new System.Windows.Forms.TextBox();
            this.lblGoalCompletion = new System.Windows.Forms.Label();
            this.lblGoalSuccessRate = new System.Windows.Forms.Label();
            this.lnklblHomeOnViewGoalPg = new System.Windows.Forms.LinkLabel();
            this.txtGoalCompletion = new System.Windows.Forms.TextBox();
            this.txtGoalPercentComplete = new System.Windows.Forms.TextBox();
            this.lblSetGoal = new System.Windows.Forms.Label();
            this.btnSetGoal = new System.Windows.Forms.Button();
            this.txtCurrentGoal = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.SuspendLayout();
            // 
            // lblViewGoal
            // 
            this.lblViewGoal.AutoSize = true;
            this.lblViewGoal.BackColor = System.Drawing.Color.White;
            this.lblViewGoal.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewGoal.Location = new System.Drawing.Point(214, 28);
            this.lblViewGoal.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblViewGoal.Name = "lblViewGoal";
            this.lblViewGoal.Size = new System.Drawing.Size(172, 37);
            this.lblViewGoal.TabIndex = 0;
            this.lblViewGoal.Text = "View Goal";
            // 
            // txtSetGoal
            // 
            this.txtSetGoal.BackColor = System.Drawing.Color.White;
            this.txtSetGoal.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.txtSetGoal.Location = new System.Drawing.Point(153, 110);
            this.txtSetGoal.Margin = new System.Windows.Forms.Padding(2);
            this.txtSetGoal.Name = "txtSetGoal";
            this.txtSetGoal.Size = new System.Drawing.Size(320, 35);
            this.txtSetGoal.TabIndex = 1;
            // 
            // lblGoalCompletion
            // 
            this.lblGoalCompletion.AutoSize = true;
            this.lblGoalCompletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblGoalCompletion.Location = new System.Drawing.Point(280, 234);
            this.lblGoalCompletion.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGoalCompletion.Name = "lblGoalCompletion";
            this.lblGoalCompletion.Size = new System.Drawing.Size(193, 25);
            this.lblGoalCompletion.TabIndex = 2;
            this.lblGoalCompletion.Text = "Goal Completion ($):";
            // 
            // lblGoalSuccessRate
            // 
            this.lblGoalSuccessRate.AutoSize = true;
            this.lblGoalSuccessRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.lblGoalSuccessRate.Location = new System.Drawing.Point(266, 280);
            this.lblGoalSuccessRate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblGoalSuccessRate.Name = "lblGoalSuccessRate";
            this.lblGoalSuccessRate.Size = new System.Drawing.Size(207, 25);
            this.lblGoalSuccessRate.TabIndex = 3;
            this.lblGoalSuccessRate.Text = "% Completion of Goal:";
            // 
            // lnklblHomeOnViewGoalPg
            // 
            this.lnklblHomeOnViewGoalPg.AutoSize = true;
            this.lnklblHomeOnViewGoalPg.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnklblHomeOnViewGoalPg.Location = new System.Drawing.Point(12, 337);
            this.lnklblHomeOnViewGoalPg.Name = "lnklblHomeOnViewGoalPg";
            this.lnklblHomeOnViewGoalPg.Size = new System.Drawing.Size(92, 25);
            this.lnklblHomeOnViewGoalPg.TabIndex = 4;
            this.lnklblHomeOnViewGoalPg.TabStop = true;
            this.lnklblHomeOnViewGoalPg.Text = "< Home";
            this.lnklblHomeOnViewGoalPg.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnklblHomeOnViewGoalPg_LinkClicked);
            // 
            // txtGoalCompletion
            // 
            this.txtGoalCompletion.BackColor = System.Drawing.Color.White;
            this.txtGoalCompletion.Enabled = false;
            this.txtGoalCompletion.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtGoalCompletion.Location = new System.Drawing.Point(478, 231);
            this.txtGoalCompletion.Name = "txtGoalCompletion";
            this.txtGoalCompletion.Size = new System.Drawing.Size(94, 30);
            this.txtGoalCompletion.TabIndex = 5;
            this.txtGoalCompletion.Text = "Goal Completion";
            this.txtGoalCompletion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtGoalPercentComplete
            // 
            this.txtGoalPercentComplete.BackColor = System.Drawing.Color.White;
            this.txtGoalPercentComplete.Enabled = false;
            this.txtGoalPercentComplete.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtGoalPercentComplete.Location = new System.Drawing.Point(478, 275);
            this.txtGoalPercentComplete.Name = "txtGoalPercentComplete";
            this.txtGoalPercentComplete.Size = new System.Drawing.Size(56, 30);
            this.txtGoalPercentComplete.TabIndex = 6;
            this.txtGoalPercentComplete.Text = "0";
            this.txtGoalPercentComplete.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblSetGoal
            // 
            this.lblSetGoal.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.lblSetGoal.AutoSize = true;
            this.lblSetGoal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSetGoal.Location = new System.Drawing.Point(17, 115);
            this.lblSetGoal.Name = "lblSetGoal";
            this.lblSetGoal.Size = new System.Drawing.Size(132, 25);
            this.lblSetGoal.TabIndex = 7;
            this.lblSetGoal.Text = "Set New Goal";
            this.lblSetGoal.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnSetGoal
            // 
            this.btnSetGoal.BackColor = System.Drawing.Color.MediumBlue;
            this.btnSetGoal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.btnSetGoal.ForeColor = System.Drawing.Color.White;
            this.btnSetGoal.Location = new System.Drawing.Point(478, 110);
            this.btnSetGoal.Name = "btnSetGoal";
            this.btnSetGoal.Size = new System.Drawing.Size(94, 35);
            this.btnSetGoal.TabIndex = 8;
            this.btnSetGoal.Text = "Set";
            this.btnSetGoal.UseVisualStyleBackColor = false;
            this.btnSetGoal.Click += new System.EventHandler(this.btnSetGoal_Click);
            // 
            // txtCurrentGoal
            // 
            this.txtCurrentGoal.BackColor = System.Drawing.Color.White;
            this.txtCurrentGoal.Enabled = false;
            this.txtCurrentGoal.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.txtCurrentGoal.HideSelection = false;
            this.txtCurrentGoal.Location = new System.Drawing.Point(478, 186);
            this.txtCurrentGoal.Name = "txtCurrentGoal";
            this.txtCurrentGoal.Size = new System.Drawing.Size(94, 30);
            this.txtCurrentGoal.TabIndex = 10;
            this.txtCurrentGoal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label1.Location = new System.Drawing.Point(314, 189);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 25);
            this.label1.TabIndex = 9;
            this.label1.Text = "Current Goal ($):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label2.Location = new System.Drawing.Point(539, 278);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 25);
            this.label2.TabIndex = 11;
            this.label2.Text = "%";
            // 
            // ViewGoal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(600, 366);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtCurrentGoal);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSetGoal);
            this.Controls.Add(this.lblSetGoal);
            this.Controls.Add(this.txtGoalPercentComplete);
            this.Controls.Add(this.txtGoalCompletion);
            this.Controls.Add(this.lnklblHomeOnViewGoalPg);
            this.Controls.Add(this.lblGoalSuccessRate);
            this.Controls.Add(this.lblGoalCompletion);
            this.Controls.Add(this.txtSetGoal);
            this.Controls.Add(this.lblViewGoal);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "ViewGoal";
            this.Text = "ViewGoal";
            this.Load += new System.EventHandler(this.ViewGoal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblViewGoal;
        private System.Windows.Forms.TextBox txtSetGoal;
        private System.Windows.Forms.Label lblGoalCompletion;
        private System.Windows.Forms.Label lblGoalSuccessRate;
        private System.Windows.Forms.LinkLabel lnklblHomeOnViewGoalPg;
        private System.Windows.Forms.TextBox txtGoalCompletion;
        private System.Windows.Forms.TextBox txtGoalPercentComplete;
        private System.Windows.Forms.Label lblSetGoal;
        private System.Windows.Forms.Button btnSetGoal;
        private System.Windows.Forms.TextBox txtCurrentGoal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}